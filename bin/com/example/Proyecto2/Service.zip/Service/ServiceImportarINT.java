package com.example.Proyecto2.Service;

import org.springframework.web.multipart.MultipartFile;

public interface ServiceImportarINT {
	String importarXml(MultipartFile file);

}
