package com.example.Proyecto2.Service;

public interface ServiceExportarINT {
	String exportarXml();

}
