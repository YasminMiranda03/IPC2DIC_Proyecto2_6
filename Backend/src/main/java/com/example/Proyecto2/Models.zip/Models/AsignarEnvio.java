package com.example.Proyecto2.Models;

public class AsignarEnvio {
	private String paqueteId;
    private String mensajeroId;

    public AsignarEnvio() {}

    public String getPaqueteId() { return paqueteId; }
    public void setPaqueteId(String paqueteId) { this.paqueteId = paqueteId; }

    public String getMensajeroId() { return mensajeroId; }
    public void setMensajeroId(String mensajeroId) { this.mensajeroId = mensajeroId; }

}
